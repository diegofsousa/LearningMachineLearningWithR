#importando csv

dados1<- read.csv("dados1.csv")

#exportando tabela em csv

write.csv(dados1,file="dados1.csv")
