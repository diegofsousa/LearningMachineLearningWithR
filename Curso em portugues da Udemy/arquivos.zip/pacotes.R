#instalar pacote
install.packages("dplyr")

#carregar pacote
library(dplyr)

