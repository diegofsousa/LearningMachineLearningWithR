#Comandos básicos no R

1+1
2-1
3*4
6/3


2^3


x<- 5
x+2

x = 4


